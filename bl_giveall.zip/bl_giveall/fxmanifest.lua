fx_version 'cerulean'
game 'gta5'

name 'bl_giveall'
author 'BL Studios'
description 'A simple admin command to give an item to every online player.'
version '1.0.0'

lua54 'yes'

dependencies {
    'ox_lib',
    'ox_inventory'
}

server_script 'server.lua'
