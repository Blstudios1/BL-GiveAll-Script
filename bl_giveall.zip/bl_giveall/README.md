## Install

1. Put the `bl_giveall` folder in your server's resources folder.
2. In `server.cfg`, make sure these resources start before BL GiveAll:
3. Give your admin group permission to use the command by adding this to `server.cfg`:


Make sure your admins are already assigned to `group.admin` in your server's ACE permissions. You can use a different ACE group if needed, but update the `add_ace` line to match.

The server console can also run the command without player permissions depending what you would like.
