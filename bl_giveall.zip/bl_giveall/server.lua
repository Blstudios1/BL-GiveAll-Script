local function notify(playerId, message, notifyType)
    if playerId == 0 then
        print(('[BL GiveAll] %s'):format(message))
        return
    end

    TriggerClientEvent('ox_lib:notify', playerId, {
        title = 'GiveAll',
        description = message,
        type = notifyType or 'inform'
    })
end

RegisterCommand('giveall', function(source, args)
    if source ~= 0 and not IsPlayerAceAllowed(source, 'giveall') then
        notify(source, 'You do not have permission to use this command.', 'error')
        return
    end

    local itemName = args[1]
    local amount = tonumber(args[2])

    if not itemName or not amount or amount < 1 or amount % 1 ~= 0 or amount > 100000 then
        notify(source, 'Usage: /giveall item amount  |  Example: /giveall water 5', 'error')
        return
    end

    local item = exports.ox_inventory:Items(itemName)
    if not item then
        notify(source, ('Item "%s" does not exist in ox_inventory.'):format(itemName), 'error')
        return
    end

    local given = 0
    local skipped = 0

    for _, playerId in ipairs(GetPlayers()) do
        local target = tonumber(playerId)

        if exports.ox_inventory:CanCarryItem(target, itemName, amount) then
            local success = exports.ox_inventory:AddItem(target, itemName, amount)

            if success then
                given = given + 1
                notify(target, ('An admin gave everyone %sx %s.'):format(amount, item.label or itemName), 'success')
            else
                skipped = skipped + 1
                notify(target, 'Your inventory could not receive the item.', 'error')
            end
        else
            skipped = skipped + 1
            notify(target, ('Your inventory is too full to receive %sx %s.'):format(amount, item.label or itemName), 'error')
        end
    end

    notify(source, ('Gave %sx %s to %s player(s). %s skipped.'):format(
        amount,
        item.label or itemName,
        given,
        skipped
    ), 'success')
end, false)
